

uniform sampler2D ColorBuffer;

void main()
{
	int Samples = 64;
	float Intensity = 0.035, Decay = 0.96875;
	vec2 TexCoord = gl_TexCoord[0].st, Direction = vec2(0.5) - TexCoord;
	Direction /= Samples;
	vec4 Color = texture2D(ColorBuffer, TexCoord);
	
	
	for(int Sample = 0; Sample < Samples; Sample++)
	{
		Color += texture2D(ColorBuffer, TexCoord) * Intensity;
		Intensity *= Decay;
		TexCoord += Direction;
	}
	
	// if (Color.rgb == vec3(0.0,0.0,0.0))
    //  discard; 
	
	//if(Color.b > 0.5)discard;
	
	
	
	gl_FragColor = Color;
}
