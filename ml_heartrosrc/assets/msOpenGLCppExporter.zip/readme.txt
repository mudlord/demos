msOpenGLCppExporter v.1.0
-------------------------

This plugin will export vertex, normal, and UV mapping arrays usuable with OpenGL C++ programs.

The data is exported to a C++ header (.h) file. Examples of the output and how to use it are included  (main.cpp & data.h).

I'm *SURE* that there is MUCH more that could be done with this, but it served my purposes in its current incarnation, so I just stopped.

If anyone has any suggestions for improving/expanding the plugin, or has a bug to report, please email me at bob_nemeth@hotmail.com.